<?php 

require_once("functions.php");
require_once("session.php");
require_once("site_config.php");
require_once("database.php");
require_once("user.php");

?>